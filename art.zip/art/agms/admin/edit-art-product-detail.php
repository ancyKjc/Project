<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if (strlen($_SESSION['agmsaid']) == 0) {
    header('location:logout.php');
    exit();
}

$eid = intval($_GET['editid']);

if (isset($_POST['submit'])) {
    $title = $_POST['title'];
    $dimension = $_POST['dimension'];
    $orientation = $_POST['orientation'];
    $size = $_POST['size'];
    $artist = $_POST['artist'];
    $arttype = $_POST['arttype'];
    $artmed = $_POST['artmed'];
    $sprice = $_POST['sprice'];
    $description = $_POST['description'];

    $query = mysqli_query($con, "UPDATE tblartproduct SET 
        Title='$title', Dimension='$dimension', Orientation='$orientation',
        Size='$size', Artist='$artist', ArtType='$arttype',
        ArtMedium='$artmed', SellingPricing='$sprice', Description='$description'
        WHERE ID='$eid'");

    if ($query) {
        echo "<script>alert('Art product has been updated.');</script>";
    } else {
        echo "<script>alert('Something went wrong. Please try again.');</script>";
    }
}

$ret = mysqli_query($con, "SELECT ap.*, ar.Name as ArtistName, at.ArtType as ArtTypeName, am.ArtMedium as ArtMediumName 
    FROM tblartproduct ap
    JOIN tblartist ar ON ar.ID = ap.Artist
    JOIN tblarttype at ON at.ID = ap.ArtType
    JOIN tblartmedium am ON am.ID = ap.ArtMedium
    WHERE ap.ID = '$eid'");
$row = mysqli_fetch_array($ret);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Art Product | Art Gallery Management System</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
</head>
<body>
<section id="container">
    <?php include_once('includes/header.php'); ?>
    <?php include_once('includes/sidebar.php'); ?>

    <section id="main-content">
        <section class="wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header"><i class="fa fa-pencil"></i> Edit Art Product</h3>
                </div>
            </div>

            <div class="row">
                <form class="form-horizontal" method="post">
                    <?php if ($row) { ?>
                        <div class="col-lg-6">
                            <section class="panel">
                                <header class="panel-heading">Product Details</header>
                                <div class="panel-body">
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Title</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" name="title" type="text" required value="<?= $row['Title']; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Dimension</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" name="dimension" type="text" required value="<?= $row['Dimension']; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Orientation</label>
                                        <div class="col-sm-10">
                                            <select class="form-control" name="orientation" required>
                                                <option value="<?= $row['Orientation']; ?>"><?= $row['Orientation']; ?></option>
                                                <option value="Portrait">Portrait</option>
                                                <option value="Landscape">Landscape</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Size</label>
                                        <div class="col-sm-10">
                                            <select class="form-control" name="size" required>
                                                <option value="<?= $row['Size']; ?>"><?= $row['Size']; ?></option>
                                                <option value="Small">Small</option>
                                                <option value="Medium">Medium</option>
                                                <option value="Large">Large</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>

                        <div class="col-lg-6">
                            <section class="panel">
                                <header class="panel-heading">Product Meta</header>
                                <div class="panel-body">
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Artist</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" name="artist" value="<?= $row['Artist']; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Art Type</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" name="arttype" value="<?= $row['ArtType']; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Art Medium</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" name="artmed" value="<?= $row['ArtMedium']; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Selling Price</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" name="sprice" type="text" required value="<?= $row['SellingPricing']; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Description</label>
                                        <div class="col-sm-10">
                                            <textarea class="form-control" name="description" rows="5" required><?= $row['Description']; ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>

                        <div class="col-lg-12 text-center">
                            <button type="submit" name="submit" class="btn btn-primary">Update</button>
                        </div>
                    <?php } else { ?>
                        <div class="col-lg-12">
                            <div class="alert alert-danger">Invalid Art Product ID.</div>
                        </div>
                    <?php } ?>
                </form>
            </div>
        </section>
    </section>

    <?php include_once('includes/footer.php'); ?>
</section>

<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.scrollTo.min.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>
