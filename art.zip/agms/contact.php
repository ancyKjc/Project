<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
?>
<!DOCTYPE html>
<html lang="zxx">
<head>
   <title>Art Gallery Management System | Contact Us Page</title>
   <script>
      addEventListener("load", function () {
         setTimeout(hideURLbar, 0);
      }, false);

      function hideURLbar() {
         window.scrollTo(0, 1);
      }
   </script>
   <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
   <link href="css/fontawesome-all.min.css" rel="stylesheet" type="text/css" media="all">
   <link rel="stylesheet" href="css/shop.css" type="text/css" />
   <link href="css/style.css" rel='stylesheet' type='text/css' media="all">
   <link href="//fonts.googleapis.com/css?family=Sunflower:500,700" rel="stylesheet">
   <link href="//fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet">
</head>
<body>
<?php include_once('includes/header.php'); ?>

<div class="inner_page-banner one-img" style="height: 600px; overflow: hidden;">
   <img src="images/p6.jpg" alt="Banner Image" style="width: 100%; height: 100%; object-fit: cover;">
</div>


<section class="subscribe" style="background-color: rgba(0, 0, 0, 0.9); padding: 80px 0; color: #fff;">
   <div class="container d-flex justify-content-center">
      <div style="background-color: rgba(0, 0, 0, 0.6); padding: 40px; border-radius: 15px; max-width: 700px; width: 100%; box-shadow: 0 0 20px rgba(255,255,255,0.1); text-align: center;">
         <?php
         $ret = mysqli_query($con, "SELECT * FROM tblpage WHERE PageType='contactus'");
         while ($row = mysqli_fetch_array($ret)) {
         ?>
            <h4 style="font-size: 2.5rem; font-weight: 600; margin-bottom: 30px;"><?php echo $row['PageTitle']; ?></h4>

            <div style="font-size: 1.1rem; margin-bottom: 25px;">
               <span class="far fa-map" style="font-size: 1.5rem; color: rgb(231, 157, 38);"></span>
               <p class="mt-2"><?php echo $row['PageDescription']; ?></p>
            </div>

            <div style="margin-bottom: 25px;">
               <span class="fas fa-phone-volume" style="font-size: 1.5rem; color: #58d68d;"></span>
               <p class="mt-2"><?php echo $row['MobileNumber']; ?><br>Time: <?php echo $row['Timing']; ?></p>
            </div>

            <div>
               <span class="far fa-envelope" style="font-size: 1.5rem; color: #5dade2;"></span>
               <p class="mt-2"><?php echo $row['Email']; ?></p>
            </div>
         <?php } ?>
      </div>
   </div>
</section>


<script src='js/jquery-2.2.3.min.js'></script>
<script src="js/minicart.js"></script>
<script>
   toys.render();
   toys.cart.on('toys_checkout', function (evt) {
      var items, len, i;
      if (this.subtotal() > 0) {
         items = this.items();
         for (i = 0, len = items.length; i < len; i++) {}
      }
   });
</script>
<script src="js/move-top.js"></script>
<script src="js/easing.js"></script>
<script>
   jQuery(document).ready(function ($) {
      $(".scroll").click(function (event) {
         event.preventDefault();
         $('html,body').animate({
            scrollTop: $(this.hash).offset().top
         }, 900);
      });
   });
</script>
<script>
   $(document).ready(function () {
      var defaults = {
         containerID: 'toTop',
         containerHoverID: 'toTopHover',
         scrollSpeed: 1200,
         easingType: 'linear'
      };
      $().UItoTop({
         easingType: 'easeOutQuart'
      });
   });
</script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
