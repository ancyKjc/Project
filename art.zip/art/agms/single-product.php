<?php
session_start();
include('includes/dbconnection.php');
?>
<!DOCTYPE html>
<html lang="zxx">
<head>
    <title>Art Gallery Management System | Single Product</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- CSS Files -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/fontawesome-all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/shop.css">
    <link rel="stylesheet" href="css/jquery-ui1.css">
    <link href="css/easy-responsive-tabs.css" rel="stylesheet">
    <link rel="stylesheet" href="css/flexslider.css">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>

<?php include_once('includes/header.php'); ?>

<!-- Banner -->
<div class="inner_page-banner one-img" style="height: 600px; overflow: hidden;">
    <img src="images/p6.jpg" alt="Banner Image" style="width: 100%; height: 100%; object-fit: cover;">
</div>

<!-- Product Section -->
<section class="banner-bottom py-lg-5 py-3">
    <div class="container">
        <div class="inner-sec-shop pt-lg-4 pt-3">
            <?php
            // Ensure product ID is provided in the query string
            $pid = isset($_GET['pid']) ? intval($_GET['pid']) : 0;

            // If a valid product ID exists
            if ($pid > 0) {
                // SQL Query to get the product details along with related info
                $query = "SELECT 
                            tblartproduct.*, 
                            tblarttype.ArtType AS typename, 
                            tblartmedium.ArtMedium AS amname, 
                            tblartist.Name AS artistname 
                          FROM tblartproduct 
                          JOIN tblarttype ON tblarttype.ID = tblartproduct.ArtType 
                          JOIN tblartmedium ON tblartmedium.ID = tblartproduct.ArtMedium 
                          JOIN tblartist ON tblartist.ID = tblartproduct.Artist 
                          WHERE tblartproduct.ID = '$pid'";

                // Execute the query
                $ret = mysqli_query($con, $query);

                // Check if the query returned any results
                if ($ret && mysqli_num_rows($ret) > 0) {
                    // Fetch product details
                    $row = mysqli_fetch_array($ret);
                    ?>

                    <div class="row">
                        <!-- Product Images -->
                        <div class="col-lg-4 single-right-left">
                            <div class="grid images_3_of_2">
                                <div class="flexslider1">
                                    <ul class="slides">
                                        <?php
                                        // Define image fields
                                        $imageFields = ['Image', 'Image1', 'Image2', 'Image3', 'Image4'];

                                        // Loop through image fields and display images
                                        foreach ($imageFields as $imgField) {
                                            if (!empty($row[$imgField])) {
                                                echo '<li data-thumb="admin/images/' . $row[$imgField] . '">
                                                        <div class="thumb-image">
                                                            <img src="admin/images/' . $row[$imgField] . '" data-imagezoom="true" class="img-fluid" alt="Art Image">
                                                        </div>
                                                    </li>';
                                            }
                                        }
                                        ?>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!-- Product Info -->
                        <div class="col-lg-8 single-right-left simpleCart_shelfItem">
                            <h3><?php echo htmlentities($row['Title']); ?> <small>(by <?php echo htmlentities($row['artistname']); ?>)</small></h3>
                            <div class="color-quality-right mt-3">
                                <h5>Size: <?php echo htmlentities($row['Size']); ?></h5>
                                <h5>Dimension: <?php echo htmlentities($row['Dimension']); ?></h5>
                                <h5>Orientation: <?php echo htmlentities($row['Orientation']); ?></h5>
                            </div>
                            <div class="occasional mt-3">
                                <h5>Art Type: <?php echo htmlentities($row['typename']); ?></h5>
                                <h5>Art Medium: <?php echo htmlentities($row['amname']); ?></h5>
                                <h5>Reference Number: <?php echo htmlentities($row['RefNum']); ?></h5>
                            </div>
                            <div class="occasion-cart mt-3">
                                <a href="art-enquiry.php?eid=<?php echo $row['ID']; ?>" class="btn btn-success text-white">Make an Enquiry</a>
                            </div>
                        </div>

                        <!-- Description -->
                        <div class="col-lg-12 mt-5">
                            <div id="horizontalTab">
                                <ul class="resp-tabs-list"><li>Description</li></ul>
                                <div class="resp-tabs-container">
                                    <div class="tab1">
                                        <h6><?php echo htmlentities($row['Title']); ?></h6>
                                        <p><?php echo nl2br(htmlentities($row['Description'])); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php
                } else {
                    // If no product is found
                    echo "<h5 class='text-danger'>No product found for the given ID.</h5>";
                }
            } else {
                // If invalid product ID is provided
                echo "<h5 class='text-danger'>Invalid product ID.</h5>";
            }
            ?>
        </div>
    </div>
</section>

<?php include_once('includes/footer.php'); ?>

<!-- JS Files -->
<script src="js/jquery-2.2.3.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/imagezoom.js"></script>
<script src="js/easy-responsive-tabs.js"></script>
<script src="js/jquery.flexslider.js"></script>
<script src="js/move-top.js"></script>
<script src="js/easing.js"></script>
<script>
    $(document).ready(function () {
        $('#horizontalTab').easyResponsiveTabs({ type: 'default', width: 'auto', fit: true });
        $().UItoTop({ easingType: 'easeOutQuart' });
    });

    $(window).on('load', function () {
        $('.flexslider1').flexslider({
            animation: "slide",
            controlNav: "thumbnails"
        });
    });
</script>
</body>
</html>
