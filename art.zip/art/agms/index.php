<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
?>
<!DOCTYPE html>
<html lang="zxx">
<head>
    <title>Art Gallery Management System | Home Page</title>
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);
        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
    <!-- Font Awesome -->
    <link href="css/fontawesome-all.min.css" rel="stylesheet" type="text/css" media="all">
    <!-- Sliders and Effects -->
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="all" />
    <link href="css/JiSlider.css" rel="stylesheet">
    <!-- Shop cart -->
    <link rel="stylesheet" href="css/shop.css" type="text/css" />
    <!-- Custom Style -->
    <link href="css/style.css" rel='stylesheet' type='text/css' media="all">
    <!-- Fonts -->
    <link href="//fonts.googleapis.com/css?family=Sunflower:500,700" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet">
    <style>
        .card {
            background: #f3f3f3;
            border-radius: 20px;
            border: 1px solid #d1d1d1;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
        }

        .product-card {
            padding: 20px;
            margin-bottom: 30px;
        }

        /* Added margin above the Best Products heading */
        #best-products {
            margin-top: 70px;
        }
    </style>
</head>
<body>
<?php include_once('includes/header.php'); ?>

<!-- Slider -->
<div class="slider text-center">
    <div class="callbacks_container">
        <ul class="rslides" id="slider4">
            <li>
                <div class="slider-img one-img" style="background-image: url('images/p6.jpg'); background-size: cover; background-position: center; height: 500px;">
                    <div class="container">
                        <div class="slider-info">
                            <h5>Welcome to Our <br>Space!</h5>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</div>

<!-- Best Products Section -->
<section class="about py-lg-4 py-md-3 py-sm-3 py-5" id="best-products">
    <div class="container py-lg-5 py-md-5 py-sm-4 py-4">
        <h3 class="title text-center mb-lg-5 mb-md-4 mb-sm-4 mb-3">Best Products</h3>
        <div class="row">
            <?php
            $products = [
                ["img" => "images/a1.jpg", "title" => "Sculptures"],
                ["img" => "images/a2.jpg", "title" => "Serigraphs"],
                ["img" => "images/a3.jpg", "title" => "Prints"],
                ["img" => "images/paint.jpg", "title" => "Painting"],
                ["img" => "images/a5.jpg", "title" => "Street Art"],
                ["img" => "images/visual.jpg", "title" => "Visuals Arts"]
            ];
            foreach ($products as $prod) {
                echo '
                <div class="col-lg-4 col-md-6 col-sm-12 text-center product-card">
                    <div class="card h-100">
                        <img src="'.$prod["img"].'" class="card-img-top img-thumbnail mx-auto d-block mt-3" style="width:200px; height:200px;" alt="">
                        <div class="card-body">
                            <h4 class="card-title">'.$prod["title"].'</h4>
                        </div>
                    </div>
                </div>';
            }
            ?>
        </div>
    </div>
</section>

<!-- About Us Section in Card -->
<section class="about py-lg-4 py-md-3 py-sm-3 py-3">
    <div class="container py-lg-5 py-md-5 py-sm-4 py-4">
        <?php
        $ret = mysqli_query($con, "SELECT * FROM tblpage WHERE PageType='aboutus'");
        while ($row = mysqli_fetch_array($ret)) {
        ?>
        <h3 class="title text-center mb-lg-5 mb-md-4 mb-sm-4 mb-3"><?php echo $row['PageTitle']; ?></h3>
        <div class="row justify-content-center">
            <div class="col-lg-10 col-md-12">
                <div class="card shadow-lg p-4 border-0">
                    <div class="card-body">
                        <p class="text-justify" style="font-size: 1.1rem; line-height: 1.8;">
                            <?php echo nl2br($row['PageDescription']); ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <?php } ?>
    </div>
</section>

<?php include_once('includes/footer.php'); ?>

<!-- Scripts -->
<script src='js/jquery-2.2.3.min.js'></script>
<script src="js/minicart.js"></script>
<script>
    toys.render();
    toys.cart.on('toys_checkout', function (evt) {
        var items, len, i;
        if (this.subtotal() > 0) {
            items = this.items();
            for (i = 0, len = items.length; i < len; i++) {}
        }
    });
</script>
<script src="js/responsiveslides.min.js"></script>
<script>
    $(function () {
        $("#slider4").responsiveSlides({
            auto: true,
            pager: false,
            nav: true,
            speed: 900,
            namespace: "callbacks"
        });
    });
</script>
<script src="js/jquery.flexisel.js"></script>
<script>
    $(window).load(function() {
        $("#flexiselDemo1").flexisel({
            visibleItems: 3,
            animationSpeed: 3000,
            autoPlay: true,
            autoPlaySpeed: 2000,
            pauseOnHover: true,
            enableResponsiveBreakpoints: true,
            responsiveBreakpoints: {
                portrait: { changePoint: 480, visibleItems: 1 },
                landscape: { changePoint: 640, visibleItems: 2 },
                tablet: { changePoint: 768, visibleItems: 2 }
            }
        });
    });
</script>
<script src="js/move-top.js"></script>
<script src="js/easing.js"></script>
<script>
    jQuery(document).ready(function ($) {
        $(".scroll").click(function (event) {
            event.preventDefault();
            $('html,body').animate({
                scrollTop: $(this.hash).offset().top
            }, 900);
        });
    });
</script>
<script>
    $(document).ready(function () {
        $().UItoTop({
            easingType: 'easeOutQuart'
        });
    });
</script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
