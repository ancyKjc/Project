<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if (isset($_POST['login'])) {
  $adminuser = $_POST['username'];
  $password = md5($_POST['password']);
  $query = mysqli_query($con, "SELECT ID FROM tbladmin WHERE UserName='$adminuser' && Password='$password'");
  $ret = mysqli_fetch_array($query);
  if ($ret > 0) {
    $_SESSION['agmsaid'] = $ret['ID'];
    echo "<script type='text/javascript'> document.location ='dashboard.php'; </script>";
  } else {
    echo "<script>alert('Invalid Details');</script>";
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>Login | Art Gallery Management System</title>

  <!-- Bootstrap CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/bootstrap-theme.css" rel="stylesheet">
  <!-- Font icon -->
  <link href="css/elegant-icons-style.css" rel="stylesheet" />
  <link href="css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet" />

  <style>
    body {
      margin: 0;
      font-family: 'Open Sans', sans-serif;
      background: url("../images/admin.jpg") no-repeat center center fixed;
      background-size: cover;
      height: 100vh;
    }

    .wrapper {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100%;
    }

    .login-form {
      background-color: rgba(0, 0, 0, 0.75);
      padding: 40px 30px;
      border-radius: 15px;
      color: #fff;
      width: 100%;
      max-width: 400px;
      box-shadow: 0 0 15px rgba(0, 0, 0, 0.5);
    }

    .login-img i {
      color: #f1c40f;
      font-size: 50px;
      display: block;
      text-align: center;
      margin-bottom: 20px;
    }

    .input-group {
      margin-bottom: 20px;
    }

    .login-form input {
      background-color: #f5f5f5;
      color: #000;
    }

    .login-form a {
      color: #f1c40f;
    }

    .login-form button {
      background-color: #f1c40f;
      border: none;
      color: #000;
      font-weight: bold;
      margin-top: 10px;
    }

    .login-form button:hover {
      background-color: #d4ac0d;
    }

    .login-form p {
      text-align: center;
      margin-top: 15px;
    }
  </style>
</head>

<body>

  <div class="wrapper">
    <form class="login-form" action="" method="post">
      <div class="login-wrap">
        <p class="login-img"><i class="icon_lock_alt"></i></p>
        <div class="input-group">
          <span class="input-group-addon"><i class="icon_profile"></i></span>
          <input type="text" class="form-control" name="username" placeholder="Username" required>
        </div>
        <div class="input-group">
          <span class="input-group-addon"><i class="icon_key_alt"></i></span>
          <input type="password" class="form-control" name="password" placeholder="Password" required>
        </div>
        <label><span class="pull-right"><a href="forgot-password.php">Forgot Password?</a></span></label>
        <button class="btn btn-primary btn-lg btn-block" type="submit" name="login">Login</button>
        <p><a href="../index.php">Back to Home page</a></p>
      </div>
    </form>
  </div>

</body>

</html>
